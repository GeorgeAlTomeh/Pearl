const container = document.getElementById("container");
const threeDots = document.getElementById("threeDots");
const settingsList = document.getElementById("settingsList");
const search = document.getElementById("search");
const searchFormGroup = document.getElementById("search-form-group");
const camera = document.getElementById("camera");
const right = document.getElementById("right");
const nav = document.getElementById("nav");

let settingsListState = 'none';
let searchState = 'none';

threeDots.onclick = function()
{
  if (settingsListState == 'none')
  {
    settingsListState = 'block';
  }
  else
  {
    settingsListState = 'none';
  }
  settingsList.style.display = settingsListState;
}

search.onclick = function()
{
  let tmpStateForRAndL;
  if (searchState == 'none')
  {
    searchState= 'block';
    tmpStateForRAndL = 'none';
    nav.style.display = 'block';
  }
  else
  {
    searchState = 'none';
    tmpStateForRAndL = 'block';
    nav.style.display = 'flex';
  }
  right.style.display = tmpStateForRAndL;
  camera.style.display = tmpStateForRAndL;
  threeDots.style.display = tmpStateForRAndL;
  search.style.display = tmpStateForRAndL;
  searchFormGroup.style.display = searchState;
}